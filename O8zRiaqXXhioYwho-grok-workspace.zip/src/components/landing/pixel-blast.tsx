import { useEffect, useRef } from "react";

export function PixelBlast() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const parent = canvas.parentElement;
    if (!parent) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    const mouse = { x: -9999, y: -9999, vx: 0, vy: 0 };
    const last = { x: -9999, y: -9999 };
    let t = 0;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const size = 10;
    const gap = 3;
    const cell = size + gap;

    const resize = () => {
      const r = parent.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = r.width;
      h = r.height;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      mouse.vx = x - last.x;
      mouse.vy = y - last.y;
      last.x = mouse.x = x;
      last.y = mouse.y = y;
    };

    const onLeave = () => {
      mouse.x = mouse.y = -9999;
    };

    const draw = () => {
      t += 0.016;
      ctx.clearRect(0, 0, w, h);
      const cols = Math.ceil(w / cell) + 1;
      const rows = Math.ceil(h / cell) + 1;
      const radius = 110;

      for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
          const px = x * cell + 1;
          const py = y * cell + 1;
          const dx = px - mouse.x;
          const dy = py - mouse.y;
          const dist = Math.hypot(dx, dy);
          const wave = reduce
            ? 0
            : Math.sin(x * 0.55 + y * 0.4 + t * 1.4) * 0.5 + 0.5;
          let glow = 0.07 + wave * 0.05;
          if (dist < radius) {
            const k = 1 - dist / radius;
            glow += k * k * 0.85;
          }
          const a = Math.min(1, glow);
          if (a < 0.04) continue;
          const mix = Math.min(1, glow);
          const rC = Math.round(165 + (255 - 165) * mix);
          const gC = Math.round(88 + (255 - 88) * mix * 0.55);
          const bC = Math.round(251 + (255 - 251) * 0);
          ctx.fillStyle = `rgba(${rC},${gC},${bC},${a * 0.55})`;
          const s = size * (0.7 + Math.min(0.5, glow * 0.45));
          ctx.fillRect(px, py, s, s);
        }
      }
      raf = requestAnimationFrame(draw);
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(parent);
    parent.addEventListener("pointermove", onMove);
    parent.addEventListener("pointerleave", onLeave);
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      parent.removeEventListener("pointermove", onMove);
      parent.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden" aria-label="PixelBlast interactive background">
      <canvas ref={canvasRef} className="block h-full w-full" />
    </div>
  );
}
