import { useEffect, useRef, useState } from "react";
import { clamp } from "@/lib/utils";
import { CubeMark } from "./icons";
import { DownloadCta } from "./download-cta";
import { GlowOrb } from "./glow-orb";
import { TestimonialsMarquee } from "./testimonials-marquee";

export function Hero() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const update = () => {
      const el = trackRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const total = el.offsetHeight - window.innerHeight;
      const p = clamp(-rect.top / Math.max(total, 1), 0, 1);
      setProgress(reduce ? 0 : p);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);

  const textOpacity = clamp(1 - progress / 0.42, 0, 1);
  const textY = -80 - progress * 90;
  const textBlur = progress * 14;
  const shotOpacity = clamp((progress - 0.18) / 0.5, 0, 1);
  const shotScale = 0.85 + clamp((progress - 0.18) / 0.7, 0, 1) * 0.15;
  const shotY = 60 - clamp((progress - 0.18) / 0.6, 0, 1) * 60;

  return (
    <div ref={trackRef} className="relative h-[180vh] w-full">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        <GlowOrb progress={progress} />

        <div
          className="pointer-events-auto absolute inset-0 z-10 -mt-48 flex flex-col items-center justify-center gap-6 px-6 text-center sm:-mt-56"
          style={{
            transform: `translateY(${textY}px)`,
            opacity: textOpacity,
            filter: `blur(${textBlur}px)`,
          }}
        >
          <h1
            className="hero-enter flex flex-wrap items-center justify-center text-balance text-3xl leading-[1.1] tracking-tight text-white sm:flex-nowrap sm:text-[80px]"
            style={{ animationDelay: "40ms" }}
          >
            <span>Hunt faster</span>
            <span
              className="inline-flex items-center justify-center overflow-visible align-middle"
              style={{ marginLeft: "0.3em", marginRight: "0.3em" }}
            >
              <span
                className="inline-block"
                style={{ animation: "float-mark 3.4s ease-in-out infinite" }}
              >
                <CubeMark className="block h-[0.8em] w-[0.8em]" />
              </span>
            </span>
            <span className="font-medium text-zinc-400">See deeper</span>
          </h1>
          <p
            className="hero-enter max-w-2xl text-pretty text-xs leading-relaxed text-zinc-400 sm:text-sm"
            style={{ animationDelay: "140ms" }}
          >
            The modern open-source OSINT platform designed to orchestrate your
            sources, identities, and breach intel in a unified interface.
          </p>
          <div className="hero-enter" style={{ animationDelay: "240ms" }}>
            <DownloadCta />
          </div>
        </div>

        <div
          className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center"
          style={{
            opacity: shotOpacity,
            transform: `translateY(${shotY}px) scale(${shotScale})`,
          }}
        >
          <div className="relative aspect-[3/2] w-full max-w-[280px] sm:max-w-[400px] md:max-w-[640px] lg:max-w-[960px]">
            <div className="absolute inset-0 overflow-hidden rounded-3xl shadow-[0_32px_100px_rgba(0,0,0,0.55)] ring-1 ring-white/10">
              <img
                alt="BrokeBase OSINT desk preview"
                className="h-full w-full object-cover"
                src="/screenshot.jpg"
              />
            </div>
          </div>
        </div>

        <TestimonialsMarquee progress={progress} />
      </div>
    </div>
  );
}
