import { Link } from "@tanstack/react-router";
import { brand } from "@/lib/content";
import { DownloadCta } from "./download-cta";
import { LayersMark } from "./icons";
import { PixelBlast } from "./pixel-blast";

export function CtaSection() {
  return (
    <section className="relative z-30 flex min-h-screen w-full flex-col items-center justify-between overflow-hidden bg-black px-6 pb-10 pt-20">
      <div className="hidden h-6 lg:block" />
      <div className="relative my-auto w-full max-w-5xl rounded-[2rem] border border-white/10 bg-gradient-to-b from-white/10 via-white/5 to-transparent p-1.5 shadow-[0_32px_100px_rgba(0,0,0,0.9),0_0_0_1px_rgba(255,255,255,0.1),inset_0_1px_1px_rgba(255,255,255,0.25)] sm:p-2">
        <div className="relative flex w-full flex-col justify-between gap-10 overflow-hidden rounded-[1.6rem] border border-white/5 bg-zinc-950/90 p-8 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),inset_0_-1px_0_rgba(0,0,0,0.9)] backdrop-blur-2xl sm:gap-14 sm:p-12 md:p-14">
          <div className="pointer-events-none absolute inset-0 z-0 opacity-30">
            <PixelBlast />
          </div>
          <div className="relative z-10 flex max-w-xl flex-col items-start text-left">
            <h2 className="text-2xl font-bold leading-snug tracking-tight text-white sm:text-3xl lg:text-4xl">
              Ready to elevate your investigations?
            </h2>
            <p className="mt-4 text-pretty text-xs font-normal leading-relaxed text-zinc-400 sm:text-sm">
              Free to start, open source, and built for modern speed. Download
              today and supercharge your OSINT workflow.
            </p>
          </div>
          <div className="relative z-10 ml-auto flex items-center justify-end self-end">
            <DownloadCta />
          </div>
        </div>
      </div>
      <footer className="z-10 flex w-full max-w-5xl flex-col items-center justify-between gap-6 border-t border-white/10 pb-4 pt-8 text-xs text-zinc-400 sm:flex-row">
        <div className="flex items-center gap-3">
          <LayersMark className="size-4 text-zinc-400" />
          <span>
            © {brand.year} {brand.legal} All rights reserved.
          </span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
          <a
            href="https://github.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-zinc-300"
          >
            GitHub
          </a>
          <a
            href="https://discord.gg/"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-zinc-300"
          >
            Discord
          </a>
          <a
            href="https://x.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-zinc-300"
          >
            Twitter
          </a>
          <Link to="/download" className="transition-colors hover:text-zinc-300">
            Download
          </Link>
          <Link to="/docs" className="transition-colors hover:text-zinc-300">
            Documentation
          </Link>
          <Link to="/changelog" className="transition-colors hover:text-zinc-300">
            Changelog
          </Link>
        </div>
      </footer>
    </section>
  );
}
