type Props = {
  progress: number;
};

export function GlowOrb({ progress }: Props) {
  const y = -50 + progress * -18;
  const blur = progress * 6;
  const opacity = 1 - progress * 0.25;
  const scale = 1.32 - progress * 0.18;

  return (
    <div
      className="absolute inset-0"
      style={{
        opacity,
        filter: `blur(${blur}px)`,
        transform: `translateY(${progress * -40}px)`,
      }}
    >
      <div
        className="pointer-events-none absolute h-full w-full"
        style={{
          isolation: "isolate",
          transform: `translateY(${y}%)`,
        }}
      >
        <div
          aria-hidden
          className="absolute inset-0 rounded-[100%]"
          style={{
            background: "rgb(255, 255, 255)",
            boxShadow: "rgba(255, 255, 255, 0.71) 0px -4px 23px 0px",
            transform: `scale(${scale})`,
          }}
        />
        <div
          aria-hidden
          className="absolute inset-0 rounded-[100%]"
          style={{
            background: "rgb(165, 88, 251)",
            filter: "blur(31px)",
            transform: "scale(1.2)",
          }}
        />
        <div
          aria-hidden
          className="absolute inset-0 rounded-[100%]"
          style={{
            background: "rgb(73, 34, 229)",
            filter: "blur(21px)",
            transform: "scale(1.24)",
          }}
        />
        <div
          aria-hidden
          className="absolute inset-0 rounded-[100%]"
          style={{
            background: "rgb(0, 0, 0)",
            filter: "blur(51px)",
            transform: "scale(1.2)",
          }}
        />
      </div>
    </div>
  );
}
