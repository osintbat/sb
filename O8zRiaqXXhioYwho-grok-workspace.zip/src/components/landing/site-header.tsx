import { Link } from "@tanstack/react-router";
import { brand } from "@/lib/content";
import { LayersMark, StarMark } from "./icons";

export function SiteHeader() {
  return (
    <>
      <div
        className="pointer-events-none fixed left-0 z-40 w-full select-none"
        style={{
          top: 0,
          height: 120,
          background: "linear-gradient(to top, transparent, rgb(0, 0, 0))",
          maskImage: "linear-gradient(rgb(0, 0, 0) 50%, transparent)",
          backdropFilter: "blur(8px)",
        }}
      />
      <div className="fixed top-2 left-1/2 z-50 flex -translate-x-1/2 select-none items-center gap-2">
        <Link
          to="/"
          className="flex items-center gap-[0.3em] text-lg font-semibold text-zinc-200"
        >
          <LayersMark className="inline-block h-[0.85em] w-auto text-white" />
          <span>{brand.name}</span>
        </Link>
        <a
          href="https://github.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="relative z-0 flex isolate cursor-pointer select-none items-center overflow-hidden whitespace-nowrap rounded-full bg-zinc-900/80 px-2.5 py-1 text-[10px] font-medium text-zinc-300 shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_4px_12px_-4px_rgba(0,0,0,0.6)] backdrop-blur-md transition-[box-shadow,background-color,scale] duration-200 ease-out hover:bg-zinc-800/90 hover:shadow-[0_0_0_1px_rgba(255,255,255,0.15),0_8px_20px_-8px_rgba(0,0,0,0.7)] active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/40"
          aria-label={`${brand.stars} stars on GitHub`}
        >
          <span className="relative z-10 flex items-center gap-1.5 whitespace-nowrap">
            <StarMark className="size-3 flex-none text-amber-400" />
            <span className="whitespace-nowrap leading-none">
              <span className="tabular-nums">{brand.stars}</span>
              <span> stars</span>
            </span>
          </span>
        </a>
      </div>
    </>
  );
}
