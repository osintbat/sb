import type { ComponentType, SVGProps } from "react";
import {
  ClaudeMark,
  CubeMark,
  CursorMark,
  LayersMark,
  OpenAiMark,
  TerminalMark,
} from "./icons";

function OrbitIcon({
  Icon,
  start,
  duration,
  dir,
}: {
  Icon: ComponentType<SVGProps<SVGSVGElement>>;
  start: number;
  duration: number;
  dir: "cw" | "ccw";
}) {
  const orbit = dir === "cw" ? "orbit-cw" : "orbit-ccw";
  const counter = dir === "cw" ? "counter-cw" : "counter-ccw";
  return (
    <div
      data-orbit
      className="pointer-events-none absolute top-0 left-1/2 flex h-1/2 origin-bottom -ml-6 flex-col items-center justify-start"
      style={{
        ["--start-angle" as string]: `${start}deg`,
        animation: `${duration}s linear infinite ${orbit}`,
      }}
    >
      <div
        className="pointer-events-auto -mt-6"
        style={{
          ["--start-angle" as string]: `${start}deg`,
          animation: `${duration}s linear infinite ${counter}`,
        }}
      >
        <div className="relative z-30 flex size-12 rounded-full border border-white/20 bg-zinc-900 shadow-md transition-transform duration-300 hover:scale-110">
          <div className="m-auto flex items-center justify-center *:size-5">
            <Icon />
          </div>
        </div>
      </div>
    </div>
  );
}

export function Integrations() {
  return (
    <section className="relative z-30 flex min-h-screen w-full items-center justify-center overflow-hidden bg-black py-20 md:py-28">
      <div className="mx-auto w-full max-w-6xl px-6">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-8">
          <div className="z-20 flex flex-col items-start text-left lg:col-span-6">
            <h2 className="mb-4 text-3xl font-bold leading-[1.1] tracking-tight text-white sm:text-4xl lg:text-5xl">
              Seamless integrations.
            </h2>
            <p className="mb-8 max-w-xl text-pretty text-xs font-normal leading-relaxed text-muted-foreground sm:text-sm">
              Connect seamlessly with your favorite OSINT tools, breach sources,
              and APIs. Plug in with the credentials and infrastructure you
              already have — BrokeBase orchestrates everything cleanly in one
              cohesive desk.
            </p>
            <div className="flex w-full items-center gap-[1px] sm:w-auto">
              {["Modular architecture", "Zero vendor lock-in", "Extensible plugins"].map(
                (label, i) => (
                  <div
                    key={label}
                    className={[
                      "flex flex-1 items-center justify-center bg-zinc-900/60 px-3 py-1 text-center origin-left sm:flex-initial",
                      i === 0
                        ? "rounded-l-full rounded-r-xs"
                        : i === 2
                          ? "rounded-r-full rounded-l-xs"
                          : "rounded-xs",
                    ].join(" ")}
                  >
                    <span className="whitespace-nowrap text-[11px] font-medium text-zinc-400">
                      {label}
                    </span>
                  </div>
                ),
              )}
            </div>
          </div>

          <div className="relative flex min-h-[360px] items-center justify-center sm:min-h-[420px] lg:col-span-6">
            <div className="flex w-full items-center justify-center">
              <div className="relative mx-auto flex aspect-16/10 w-full max-w-[22rem] items-center justify-between overflow-visible p-6 sm:max-w-sm [mask-image:linear-gradient(to_bottom,black_0%,black_75%,transparent_100%)] [-webkit-mask-image:linear-gradient(to_bottom,black_0%,black_75%,transparent_100%)]">
                <div className="absolute inset-6 flex aspect-square items-center justify-center rounded-full border-t border-white/15 bg-gradient-to-b from-white/10 to-transparent to-25%">
                  <OrbitIcon Icon={ClaudeMark} start={-60} duration={25} dir="cw" />
                  <OrbitIcon Icon={OpenAiMark} start={60} duration={25} dir="cw" />
                  <OrbitIcon Icon={CubeMark} start={180} duration={25} dir="cw" />
                </div>
                <div className="absolute inset-20 flex aspect-square scale-90 items-center justify-center rounded-full border-t border-white/15 bg-gradient-to-b from-white/10 to-transparent to-25%">
                  <OrbitIcon Icon={CursorMark} start={-45} duration={20} dir="ccw" />
                  <OrbitIcon Icon={TerminalMark} start={135} duration={20} dir="ccw" />
                </div>
                <div className="absolute inset-x-0 bottom-0 mx-auto my-2 flex w-fit justify-center gap-2">
                  <div className="relative z-20 rounded-full border border-white/20 bg-black p-1">
                    <div className="flex size-16 items-center justify-center rounded-full bg-black shadow-2xl shadow-white/10">
                      <LayersMark className="size-8 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
