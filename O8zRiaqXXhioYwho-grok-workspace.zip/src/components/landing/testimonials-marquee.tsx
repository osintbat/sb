import { testimonials } from "@/lib/content";
import { XMark } from "./icons";

function Card({
  name,
  handle,
  avatar,
  quote,
}: (typeof testimonials)[number]) {
  return (
    <div
      className="group relative z-0 block w-[280px] flex-none cursor-pointer select-none overflow-hidden isolate rounded-2xl bg-zinc-900/90 p-3 text-left text-white shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_1px_2px_-1px_rgba(0,0,0,0.5)] backdrop-blur-md transition-[box-shadow,background-color,translate,scale] duration-200 ease-out hover:-translate-y-0.5 hover:bg-zinc-800/90 hover:shadow-[0_0_0_1px_rgba(255,255,255,0.15),0_12px_32px_-12px_rgba(0,0,0,0.7)] active:translate-y-0 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/40"
      role="blockquote"
    >
      <div className="relative z-10 pointer-events-none">
        <div className="flex items-start gap-2.5">
          <img
            alt={`${handle} avatar`}
            width={36}
            height={36}
            className="size-9 flex-none rounded-full object-cover outline outline-1 -outline-offset-1 outline-white/10 transition-transform duration-200 ease-out group-hover:scale-[1.05]"
            src={avatar}
          />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13px] font-semibold leading-tight text-zinc-100">
              {name}
            </div>
            <div className="mt-0.5 truncate text-[11px] leading-tight text-zinc-400">
              {handle}
            </div>
          </div>
          <XMark className="mt-0.5 size-3.5 flex-none text-zinc-400 transition-colors duration-200 ease-out group-hover:text-zinc-300" />
        </div>
        <p className="mt-2 line-clamp-2 text-xs leading-[1.45] text-zinc-300 transition-colors duration-200 ease-out group-hover:text-zinc-200">
          “{quote}”
        </p>
      </div>
    </div>
  );
}

export function TestimonialsMarquee({ progress }: { progress: number }) {
  const loop = [...testimonials, ...testimonials, ...testimonials];
  const opacity = 1 - Math.max(0, (progress - 0.55) / 0.45);
  const blur = progress > 0.6 ? (progress - 0.6) * 12 : 0;
  const y = progress * 12;

  return (
    <div
      className="absolute bottom-4 left-0 right-0 z-40"
      style={{
        opacity,
        filter: `blur(${blur}px)`,
        transform: `translateY(${y}px)`,
        pointerEvents: opacity < 0.2 ? "none" : "auto",
      }}
    >
      <p className="mb-3 text-center text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-400">
        Trusted by hunters and analysts worldwide
      </p>
      <div className="mask-marquee overflow-hidden">
        <div className="animate-marquee gap-3 px-4 py-1">
          {loop.map((t, i) => (
            <Card key={`${t.handle}-${i}`} {...t} />
          ))}
        </div>
      </div>
    </div>
  );
}
