import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { detectPlatform, type PlatformId } from "@/lib/utils";
import { platforms } from "@/lib/content";
import { TactileButton } from "./tactile-button";
import {
  AppleMark,
  ChevronDown,
  GithubMark,
  LinuxMark,
  WindowsMark,
} from "./icons";

const marks = {
  windows: WindowsMark,
  macos: AppleMark,
  linux: LinuxMark,
};

export function DownloadCta() {
  const [platform, setPlatform] = useState<PlatformId>("windows");

  useEffect(() => {
    setPlatform(detectPlatform());
  }, []);

  const current = platforms.find((p) => p.id === platform) ?? platforms[0];
  const Mark = marks[current.id];

  return (
    <div className="flex flex-col gap-3 sm:flex-row mt-2">
      <div className="inline-flex items-stretch justify-center gap-[2px]">
        <Link to="/download" className="inline-flex self-stretch">
          <TactileButton split="left" className="!h-auto self-stretch">
            <Mark className="size-4" />
            Download for {current.label}
          </TactileButton>
        </Link>
        <DropdownMenu.Root>
          <DropdownMenu.Trigger asChild>
            <TactileButton
              split="right"
              aria-label="Download for other platforms"
              type="button"
            >
              <ChevronDown className="size-4" />
            </TactileButton>
          </DropdownMenu.Trigger>
          <DropdownMenu.Portal>
            <DropdownMenu.Content
              align="end"
              sideOffset={8}
              className="z-50 min-w-48 overflow-hidden rounded-xl border border-white/10 bg-zinc-950/95 p-1.5 shadow-2xl backdrop-blur-xl data-[state=open]:animate-in"
            >
              {platforms.map((p) => {
                const Icon = marks[p.id];
                return (
                  <DropdownMenu.Item key={p.id} asChild>
                    <Link
                      to="/download"
                      className="flex cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-zinc-200 outline-none hover:bg-white/10 focus:bg-white/10"
                    >
                      <Icon className="size-4 text-zinc-300" />
                      <span className="flex-1">{p.label}</span>
                      <span className="font-mono text-[10px] text-zinc-500">{p.file.split(".").pop()}</span>
                    </Link>
                  </DropdownMenu.Item>
                );
              })}
            </DropdownMenu.Content>
          </DropdownMenu.Portal>
        </DropdownMenu.Root>
      </div>
      <a
        href="https://github.com/"
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex"
      >
        <TactileButton variant="ghost">
          <GithubMark className="size-4" />
          Source
        </TactileButton>
      </a>
    </div>
  );
}
