import type { ReactNode } from "react";
import { SiteHeader } from "./site-header";

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen w-full bg-black text-white">
      <SiteHeader />
      {children}
    </div>
  );
}
