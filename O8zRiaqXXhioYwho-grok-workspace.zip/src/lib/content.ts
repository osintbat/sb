export const brand = {
  name: "BrokeBase",
  tagline: "Open-source OSINT workstation",
  stars: "18k",
  year: 2026,
  legal: "BrokeBase Inc.",
};

export const platforms = [
  {
    id: "windows" as const,
    label: "Windows",
    file: "BrokeBase-Setup-1.4.2.exe",
    href: "/download",
  },
  {
    id: "macos" as const,
    label: "macOS",
    file: "BrokeBase-1.4.2.dmg",
    href: "/download",
  },
  {
    id: "linux" as const,
    label: "Linux",
    file: "BrokeBase-1.4.2.AppImage",
    href: "/download",
  },
];

export const testimonials = [
  {
    name: "Alex Rivera",
    handle: "@alexrivera",
    avatar: "/avatars/alex.jpg",
    quote:
      "BrokeBase completely leveled up our threat hunts. Clean graph, gorgeous motion, and ridiculously easy to wire in new sources.",
  },
  {
    name: "Sarah Chen",
    handle: "@sarah_dev",
    avatar: "/avatars/sarah.jpg",
    quote:
      "The motion choreography is top tier. Swapped our old recon stack and had a live case file in under an hour.",
  },
  {
    name: "Marcus Vance",
    handle: "@marcus_ui",
    avatar: "/avatars/marcus.jpg",
    quote:
      "Incredible attention to detail. The progressive blur, tactile buttons, and identity graph feel like a million bucks.",
  },
  {
    name: "Elena Rostova",
    handle: "@elena_osint",
    avatar: "/avatars/elena.jpg",
    quote:
      "The dark-mode aesthetic and plugin system are absolutely flawless. Finally an OSINT desk that doesn’t look like 2014.",
  },
  {
    name: "Jordan Lee",
    handle: "@jordan_tech",
    avatar: "/avatars/jordan.jpg",
    quote:
      "Best OSINT workstation I’ve used. The code is modular, type-safe, and the breach correlation actually holds up in court notes.",
  },
  {
    name: "Samir Patel",
    handle: "@dev_sam",
    avatar: "/avatars/samir.jpg",
    quote:
      "Performance is buttery smooth even with full graph shaders and live source fan-out across a thousand nodes.",
  },
];

export const docsNav = [
  { href: "/docs#hunt", label: "Hunt" },
  { href: "/docs#graph", label: "Identity graph" },
  { href: "/docs#sources", label: "Sources" },
  { href: "/docs#opsec", label: "OPSEC" },
];

export const changelog = [
  {
    version: "1.4.2",
    date: "Sep 4, 2026",
    items: [
      "Faster Sherlock / WhatsMyName fan-out with cancellable jobs.",
      "Graph now clusters related breach collections.",
      "Linux AppImage signed with the BrokeBase key.",
    ],
  },
  {
    version: "1.4.0",
    date: "Aug 12, 2026",
    items: [
      "Censys + Shodan source plugins shipped.",
      "Case files: pin an identity, export PDF/JSON.",
      "Pixel-accurate dark chrome refresh.",
    ],
  },
  {
    version: "1.3.1",
    date: "Jun 28, 2026",
    items: [
      "Have I Been Pwned v3 adapter.",
      "Keyboard-first command palette.",
    ],
  },
];
