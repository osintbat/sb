import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageShell } from "@/components/landing/page-shell";
import { AppleMark, LinuxMark, WindowsMark } from "@/components/landing/icons";
import { TactileButton } from "@/components/landing/tactile-button";
import { platforms } from "@/lib/content";
import { detectPlatform, type PlatformId } from "@/lib/utils";

export const Route = createFileRoute("/download")({ component: DownloadPage });

const marks = {
  windows: WindowsMark,
  macos: AppleMark,
  linux: LinuxMark,
};

function DownloadPage() {
  const [platform, setPlatform] = useState<PlatformId>("windows");
  useEffect(() => {
    setPlatform(detectPlatform());
  }, []);

  return (
    <PageShell>
      <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col justify-center px-6 pb-24 pt-40">
        <p className="mb-3 text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500">
          Desktop builds
        </p>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
          Download BrokeBase
        </h1>
        <p className="mt-4 max-w-xl text-pretty text-sm leading-relaxed text-zinc-400">
          Native OSINT workstation for Windows, macOS, and Linux. Same engine,
          same plugins, signed builds. Pick your platform — we detected{" "}
          <span className="text-zinc-200">{platform}</span>.
        </p>

        <div className="mt-10 grid gap-3">
          {platforms.map((p) => {
            const Icon = marks[p.id];
            const active = p.id === platform;
            return (
              <div
                key={p.id}
                className={[
                  "flex items-center gap-4 rounded-2xl border p-4 backdrop-blur-md transition-colors",
                  active
                    ? "border-white/20 bg-zinc-900/90"
                    : "border-white/10 bg-zinc-950/60 hover:border-white/15",
                ].join(" ")}
              >
                <div className="flex size-12 items-center justify-center rounded-full border border-white/15 bg-zinc-900">
                  <Icon className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-zinc-100">
                    {p.label}
                    {active ? (
                      <span className="ml-2 text-[10px] font-medium uppercase tracking-wider text-zinc-500">
                        detected
                      </span>
                    ) : null}
                  </div>
                  <div className="mt-0.5 font-mono text-[11px] text-zinc-500">{p.file}</div>
                </div>
                <TactileButton
                  type="button"
                  onClick={() => {
                    const blob = new Blob(
                      [
                        `BrokeBase ${p.label} build placeholder\n${p.file}\nThis preview ships a demo landing — hook your release artifacts here.\n`,
                      ],
                      { type: "text/plain" },
                    );
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = p.file.replace(/\.\w+$/, ".txt");
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                >
                  Download
                </TactileButton>
              </div>
            );
          })}
        </div>

        <p className="mt-8 text-xs text-zinc-500">
          Looking for source?{" "}
          <a
            href="https://github.com/"
            className="text-zinc-300 underline-offset-4 hover:underline"
            target="_blank"
            rel="noopener noreferrer"
          >
            Clone the repo
          </a>
          {" · "}
          <Link to="/docs" className="text-zinc-300 underline-offset-4 hover:underline">
            Read the docs
          </Link>
        </p>
      </main>
    </PageShell>
  );
}
