import { createFileRoute } from "@tanstack/react-router";
import { CtaSection } from "@/components/landing/cta-section";
import { Hero } from "@/components/landing/hero";
import { Integrations } from "@/components/landing/integrations";
import { PageShell } from "@/components/landing/page-shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <PageShell>
      <Hero />
      <Integrations />
      <CtaSection />
    </PageShell>
  );
}
