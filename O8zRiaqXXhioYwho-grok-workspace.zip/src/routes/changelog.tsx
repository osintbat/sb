import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/landing/page-shell";
import { changelog } from "@/lib/content";

export const Route = createFileRoute("/changelog")({ component: ChangelogPage });

function ChangelogPage() {
  return (
    <PageShell>
      <main className="mx-auto min-h-screen w-full max-w-3xl px-6 pb-24 pt-40">
        <p className="mb-3 text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500">
          Release notes
        </p>
        <h1 className="text-3xl font-bold tracking-tight text-white sm:text-5xl">
          Changelog
        </h1>
        <div className="mt-14 space-y-12">
          {changelog.map((rel) => (
            <section key={rel.version}>
              <div className="flex items-baseline gap-3">
                <h2 className="font-mono text-sm font-semibold text-white">
                  v{rel.version}
                </h2>
                <span className="text-xs text-zinc-500">{rel.date}</span>
              </div>
              <ul className="mt-3 space-y-2 text-sm leading-relaxed text-zinc-400">
                {rel.items.map((item) => (
                  <li key={item} className="flex gap-2">
                    <span className="mt-2 size-1 shrink-0 rounded-full bg-zinc-600" />
                    <span className="text-pretty">{item}</span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      </main>
    </PageShell>
  );
}
