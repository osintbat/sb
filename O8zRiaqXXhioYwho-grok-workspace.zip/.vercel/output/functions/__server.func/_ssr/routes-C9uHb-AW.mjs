import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as testimonials, a as CursorMark, c as LinuxMark, d as TerminalMark, f as WindowsMark, g as platforms, i as CubeMark, l as OpenAiMark, m as brand, n as ChevronDown, o as GithubMark, p as XMark, r as ClaudeMark, s as LayersMark, t as AppleMark, u as PageShell } from "./page-shell-thmbKdRR.mjs";
import { n as clamp, r as detectPlatform, t as TactileButton } from "./tactile-button-CMgqa7fZ.mjs";
import { a as Trigger, i as Root2, n as Item2, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C9uHb-AW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var marks = {
	windows: WindowsMark,
	macos: AppleMark,
	linux: LinuxMark
};
function DownloadCta() {
	const [platform, setPlatform] = (0, import_react.useState)("windows");
	(0, import_react.useEffect)(() => {
		setPlatform(detectPlatform());
	}, []);
	const current = platforms.find((p) => p.id === platform) ?? platforms[0];
	const Mark = marks[current.id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 sm:flex-row mt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "inline-flex items-stretch justify-center gap-[2px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/download",
				className: "inline-flex self-stretch",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TactileButton, {
					split: "left",
					className: "!h-auto self-stretch",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-4" }),
						"Download for ",
						current.label
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root2, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TactileButton, {
					split: "right",
					"aria-label": "Download for other platforms",
					type: "button",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
				align: "end",
				sideOffset: 8,
				className: "z-50 min-w-48 overflow-hidden rounded-xl border border-white/10 bg-zinc-950/95 p-1.5 shadow-2xl backdrop-blur-xl data-[state=open]:animate-in",
				children: platforms.map((p) => {
					const Icon = marks[p.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/download",
							className: "flex cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-zinc-200 outline-none hover:bg-white/10 focus:bg-white/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-zinc-300" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1",
									children: p.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[10px] text-zinc-500",
									children: p.file.split(".").pop()
								})
							]
						})
					}, p.id);
				})
			}) })] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "https://github.com/",
			target: "_blank",
			rel: "noopener noreferrer",
			className: "inline-flex",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TactileButton, {
				variant: "ghost",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GithubMark, { className: "size-4" }), "Source"]
			})
		})]
	});
}
function PixelBlast() {
	const canvasRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const parent = canvas.parentElement;
		if (!parent) return;
		let raf = 0;
		let w = 0;
		let h = 0;
		const mouse = {
			x: -9999,
			y: -9999,
			vx: 0,
			vy: 0
		};
		const last = {
			x: -9999,
			y: -9999
		};
		let t = 0;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const size = 10;
		const cell = 13;
		const resize = () => {
			const r = parent.getBoundingClientRect();
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			w = r.width;
			h = r.height;
			canvas.width = Math.max(1, Math.floor(w * dpr));
			canvas.height = Math.max(1, Math.floor(h * dpr));
			canvas.style.width = `${w}px`;
			canvas.style.height = `${h}px`;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		const onMove = (e) => {
			const r = canvas.getBoundingClientRect();
			const x = e.clientX - r.left;
			const y = e.clientY - r.top;
			mouse.vx = x - last.x;
			mouse.vy = y - last.y;
			last.x = mouse.x = x;
			last.y = mouse.y = y;
		};
		const onLeave = () => {
			mouse.x = mouse.y = -9999;
		};
		const draw = () => {
			t += .016;
			ctx.clearRect(0, 0, w, h);
			const cols = Math.ceil(w / cell) + 1;
			const rows = Math.ceil(h / cell) + 1;
			const radius = 110;
			for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
				const px = x * cell + 1;
				const py = y * cell + 1;
				const dx = px - mouse.x;
				const dy = py - mouse.y;
				const dist = Math.hypot(dx, dy);
				let glow = .07 + (reduce ? 0 : Math.sin(x * .55 + y * .4 + t * 1.4) * .5 + .5) * .05;
				if (dist < radius) {
					const k = 1 - dist / radius;
					glow += k * k * .85;
				}
				const a = Math.min(1, glow);
				if (a < .04) continue;
				const mix = Math.min(1, glow);
				const rC = Math.round(165 + 90 * mix);
				const gC = Math.round(88 + 167 * mix * .55);
				ctx.fillStyle = `rgba(${rC},${gC},${Math.round(251)},${a * .55})`;
				const s = size * (.7 + Math.min(.5, glow * .45));
				ctx.fillRect(px, py, s, s);
			}
			raf = requestAnimationFrame(draw);
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(parent);
		parent.addEventListener("pointermove", onMove);
		parent.addEventListener("pointerleave", onLeave);
		raf = requestAnimationFrame(draw);
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			parent.removeEventListener("pointermove", onMove);
			parent.removeEventListener("pointerleave", onLeave);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative h-full w-full overflow-hidden",
		"aria-label": "PixelBlast interactive background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "block h-full w-full"
		})
	});
}
function CtaSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-30 flex min-h-screen w-full flex-col items-center justify-between overflow-hidden bg-black px-6 pb-10 pt-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-6 lg:block" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative my-auto w-full max-w-5xl rounded-[2rem] border border-white/10 bg-gradient-to-b from-white/10 via-white/5 to-transparent p-1.5 shadow-[0_32px_100px_rgba(0,0,0,0.9),0_0_0_1px_rgba(255,255,255,0.1),inset_0_1px_1px_rgba(255,255,255,0.25)] sm:p-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex w-full flex-col justify-between gap-10 overflow-hidden rounded-[1.6rem] border border-white/5 bg-zinc-950/90 p-8 shadow-[inset_0_1px_0_rgba(255,255,255,0.12),inset_0_-1px_0_rgba(0,0,0,0.9)] backdrop-blur-2xl sm:gap-14 sm:p-12 md:p-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-0 z-0 opacity-30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixelBlast, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 flex max-w-xl flex-col items-start text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-bold leading-snug tracking-tight text-white sm:text-3xl lg:text-4xl",
								children: "Ready to elevate your investigations?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-pretty text-xs font-normal leading-relaxed text-zinc-400 sm:text-sm",
								children: "Free to start, open source, and built for modern speed. Download today and supercharge your OSINT workflow."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative z-10 ml-auto flex items-center justify-end self-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadCta, {})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "z-10 flex w-full max-w-5xl flex-col items-center justify-between gap-6 border-t border-white/10 pb-4 pt-8 text-xs text-zinc-400 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersMark, { className: "size-4 text-zinc-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"© ",
						brand.year,
						" ",
						brand.legal,
						" All rights reserved."
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-center gap-x-5 gap-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://github.com/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "transition-colors hover:text-zinc-300",
							children: "GitHub"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://discord.gg/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "transition-colors hover:text-zinc-300",
							children: "Discord"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://x.com/",
							target: "_blank",
							rel: "noopener noreferrer",
							className: "transition-colors hover:text-zinc-300",
							children: "Twitter"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/download",
							className: "transition-colors hover:text-zinc-300",
							children: "Download"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/docs",
							className: "transition-colors hover:text-zinc-300",
							children: "Documentation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/changelog",
							className: "transition-colors hover:text-zinc-300",
							children: "Changelog"
						})
					]
				})]
			})
		]
	});
}
function GlowOrb({ progress }) {
	const y = -50 + progress * -18;
	const blur = progress * 6;
	const opacity = 1 - progress * .25;
	const scale = 1.32 - progress * .18;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0",
		style: {
			opacity,
			filter: `blur(${blur}px)`,
			transform: `translateY(${progress * -40}px)`
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute h-full w-full",
			style: {
				isolation: "isolate",
				transform: `translateY(${y}%)`
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 rounded-[100%]",
					style: {
						background: "rgb(255, 255, 255)",
						boxShadow: "rgba(255, 255, 255, 0.71) 0px -4px 23px 0px",
						transform: `scale(${scale})`
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 rounded-[100%]",
					style: {
						background: "rgb(165, 88, 251)",
						filter: "blur(31px)",
						transform: "scale(1.2)"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 rounded-[100%]",
					style: {
						background: "rgb(73, 34, 229)",
						filter: "blur(21px)",
						transform: "scale(1.24)"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 rounded-[100%]",
					style: {
						background: "rgb(0, 0, 0)",
						filter: "blur(51px)",
						transform: "scale(1.2)"
					}
				})
			]
		})
	});
}
function Card({ name, handle, avatar, quote }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "group relative z-0 block w-[280px] flex-none cursor-pointer select-none overflow-hidden isolate rounded-2xl bg-zinc-900/90 p-3 text-left text-white shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_1px_2px_-1px_rgba(0,0,0,0.5)] backdrop-blur-md transition-[box-shadow,background-color,translate,scale] duration-200 ease-out hover:-translate-y-0.5 hover:bg-zinc-800/90 hover:shadow-[0_0_0_1px_rgba(255,255,255,0.15),0_12px_32px_-12px_rgba(0,0,0,0.7)] active:translate-y-0 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/40",
		role: "blockquote",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 pointer-events-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						alt: `${handle} avatar`,
						width: 36,
						height: 36,
						className: "size-9 flex-none rounded-full object-cover outline outline-1 -outline-offset-1 outline-white/10 transition-transform duration-200 ease-out group-hover:scale-[1.05]",
						src: avatar
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-[13px] font-semibold leading-tight text-zinc-100",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0.5 truncate text-[11px] leading-tight text-zinc-400",
							children: handle
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XMark, { className: "mt-0.5 size-3.5 flex-none text-zinc-400 transition-colors duration-200 ease-out group-hover:text-zinc-300" })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 line-clamp-2 text-xs leading-[1.45] text-zinc-300 transition-colors duration-200 ease-out group-hover:text-zinc-200",
				children: [
					"“",
					quote,
					"”"
				]
			})]
		})
	});
}
function TestimonialsMarquee({ progress }) {
	const loop = [
		...testimonials,
		...testimonials,
		...testimonials
	];
	const opacity = 1 - Math.max(0, (progress - .55) / .45);
	const blur = progress > .6 ? (progress - .6) * 12 : 0;
	const y = progress * 12;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute bottom-4 left-0 right-0 z-40",
		style: {
			opacity,
			filter: `blur(${blur}px)`,
			transform: `translateY(${y}px)`,
			pointerEvents: opacity < .2 ? "none" : "auto"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-center text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-400",
			children: "Trusted by hunters and analysts worldwide"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mask-marquee overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "animate-marquee gap-3 px-4 py-1",
				children: loop.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { ...t }, `${t.handle}-${i}`))
			})
		})]
	});
}
function Hero() {
	const trackRef = (0, import_react.useRef)(null);
	const [progress, setProgress] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const update = () => {
			const el = trackRef.current;
			if (!el) return;
			const rect = el.getBoundingClientRect();
			const total = el.offsetHeight - window.innerHeight;
			const p = clamp(-rect.top / Math.max(total, 1), 0, 1);
			setProgress(reduce ? 0 : p);
		};
		update();
		window.addEventListener("scroll", update, { passive: true });
		window.addEventListener("resize", update);
		return () => {
			window.removeEventListener("scroll", update);
			window.removeEventListener("resize", update);
		};
	}, []);
	const textOpacity = clamp(1 - progress / .42, 0, 1);
	const textY = -80 - progress * 90;
	const textBlur = progress * 14;
	const shotOpacity = clamp((progress - .18) / .5, 0, 1);
	const shotScale = .85 + clamp((progress - .18) / .7, 0, 1) * .15;
	const shotY = 60 - clamp((progress - .18) / .6, 0, 1) * 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: trackRef,
		className: "relative h-[180vh] w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky top-0 h-screen w-full overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlowOrb, { progress }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto absolute inset-0 z-10 -mt-48 flex flex-col items-center justify-center gap-6 px-6 text-center sm:-mt-56",
					style: {
						transform: `translateY(${textY}px)`,
						opacity: textOpacity,
						filter: `blur(${textBlur}px)`
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "hero-enter flex flex-wrap items-center justify-center text-balance text-3xl leading-[1.1] tracking-tight text-white sm:text-[80px]",
							style: { animationDelay: "40ms" },
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hunt faster" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center justify-center overflow-visible align-middle",
									style: {
										marginLeft: "0.3em",
										marginRight: "0.3em"
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-block",
										style: { animation: "float-mark 3.4s ease-in-out infinite" },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CubeMark, { className: "block h-[0.8em] w-[0.8em]" })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-zinc-400",
									children: "See deeper"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hero-enter max-w-2xl text-pretty text-xs leading-relaxed text-zinc-400 sm:text-sm",
							style: { animationDelay: "140ms" },
							children: "The modern open-source OSINT platform designed to orchestrate your sources, identities, and breach intel in a unified interface."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hero-enter",
							style: { animationDelay: "240ms" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadCta, {})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-0 z-20 flex items-center justify-center",
					style: {
						opacity: shotOpacity,
						transform: `translateY(${shotY}px) scale(${shotScale})`
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative aspect-[3/2] w-full max-w-[280px] sm:max-w-[400px] md:max-w-[640px] lg:max-w-[960px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 overflow-hidden rounded-3xl shadow-[0_32px_100px_rgba(0,0,0,0.55)] ring-1 ring-white/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								alt: "BrokeBase OSINT desk preview",
								className: "h-full w-full object-cover",
								src: "/screenshot.jpg"
							})
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestimonialsMarquee, { progress })
			]
		})
	});
}
function OrbitIcon({ Icon, start, duration, dir }) {
	const orbit = dir === "cw" ? "orbit-cw" : "orbit-ccw";
	const counter = dir === "cw" ? "counter-cw" : "counter-ccw";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-orbit": true,
		className: "pointer-events-none absolute top-0 left-1/2 flex h-1/2 origin-bottom -ml-6 flex-col items-center justify-start",
		style: {
			["--start-angle"]: `${start}deg`,
			animation: `${duration}s linear infinite ${orbit}`
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-auto -mt-6",
			style: {
				["--start-angle"]: `${start}deg`,
				animation: `${duration}s linear infinite ${counter}`
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-30 flex size-12 rounded-full border border-white/20 bg-zinc-900 shadow-md transition-transform duration-300 hover:scale-110",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "m-auto flex items-center justify-center *:size-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
				})
			})
		})
	});
}
function Integrations() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative z-30 flex min-h-screen w-full items-center justify-center overflow-hidden bg-black py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-6xl px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "z-20 flex flex-col items-start text-left lg:col-span-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-4 text-3xl font-bold leading-[1.1] tracking-tight text-white sm:text-4xl lg:text-5xl",
							children: "Seamless integrations."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-8 max-w-xl text-pretty text-xs font-normal leading-relaxed text-muted-foreground sm:text-sm",
							children: "Connect seamlessly with your favorite OSINT tools, breach sources, and APIs. Plug in with the credentials and infrastructure you already have — BrokeBase orchestrates everything cleanly in one cohesive desk."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex w-full items-center gap-[1px] sm:w-auto",
							children: [
								"Modular architecture",
								"Zero vendor lock-in",
								"Extensible plugins"
							].map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: ["flex flex-1 items-center justify-center bg-zinc-900/60 px-3 py-1 text-center origin-left sm:flex-initial", i === 0 ? "rounded-l-full rounded-r-xs" : i === 2 ? "rounded-r-full rounded-l-xs" : "rounded-xs"].join(" "),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "whitespace-nowrap text-[11px] font-medium text-zinc-400",
									children: label
								})
							}, label))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative flex min-h-[360px] items-center justify-center sm:min-h-[420px] lg:col-span-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex w-full items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mx-auto flex aspect-16/10 w-full max-w-[22rem] items-center justify-between overflow-visible p-6 sm:max-w-sm [mask-image:linear-gradient(to_bottom,black_0%,black_75%,transparent_100%)] [-webkit-mask-image:linear-gradient(to_bottom,black_0%,black_75%,transparent_100%)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-6 flex aspect-square items-center justify-center rounded-full border-t border-white/15 bg-gradient-to-b from-white/10 to-transparent to-25%",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitIcon, {
											Icon: ClaudeMark,
											start: -60,
											duration: 25,
											dir: "cw"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitIcon, {
											Icon: OpenAiMark,
											start: 60,
											duration: 25,
											dir: "cw"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitIcon, {
											Icon: CubeMark,
											start: 180,
											duration: 25,
											dir: "cw"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute inset-20 flex aspect-square scale-90 items-center justify-center rounded-full border-t border-white/15 bg-gradient-to-b from-white/10 to-transparent to-25%",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitIcon, {
										Icon: CursorMark,
										start: -45,
										duration: 20,
										dir: "ccw"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitIcon, {
										Icon: TerminalMark,
										start: 135,
										duration: 20,
										dir: "ccw"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-x-0 bottom-0 mx-auto my-2 flex w-fit justify-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative z-20 rounded-full border border-white/20 bg-black p-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex size-16 items-center justify-center rounded-full bg-black shadow-2xl shadow-white/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersMark, { className: "size-8 text-white" })
										})
									})
								})
							]
						})
					})
				})]
			})
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Integrations, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CtaSection, {})
	] });
}
//#endregion
export { Home as component };
