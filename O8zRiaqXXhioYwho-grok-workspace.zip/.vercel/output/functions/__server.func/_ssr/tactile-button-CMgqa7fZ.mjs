import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tactile-button-CMgqa7fZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function detectPlatform() {
	if (typeof navigator === "undefined") return "windows";
	const ua = navigator.userAgent;
	if (/Mac|iPhone|iPad|iPod/.test(ua)) return "macos";
	if (/Linux|X11/.test(ua)) return "linux";
	return "windows";
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function TactileButton({ variant = "primary", split = "none", surface = true, className, children, onPointerDown, onPointerUp, onPointerLeave, onPointerMove, ...props }) {
	const ref = (0, import_react.useRef)(null);
	const [pressed, setPressed] = (0, import_react.useState)(false);
	const [spot, setSpot] = (0, import_react.useState)({
		x: 0,
		y: 0,
		on: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		ref,
		"data-pressed": pressed ? "true" : "false",
		className: cn("group relative inline-flex cursor-pointer select-none items-center justify-center overflow-hidden whitespace-nowrap font-medium tracking-[0.01em]", "transition-[background-color,color,box-shadow,border-radius] duration-300 ease-[cubic-bezier(0.2,0.8,0.2,1.2)]", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-black", "disabled:pointer-events-none disabled:opacity-[0.38] disabled:shadow-none", "[&_svg]:transition-transform [&_svg]:duration-300 [&_svg]:ease-[cubic-bezier(0.2,0.8,0.2,1.2)] data-[pressed=true]:[&_svg]:scale-[0.90]", "py-[10px] gap-[8px] text-sm border-transparent", variant === "primary" && "bg-primary text-primary-foreground shadow-sm hover:shadow", variant === "ghost" && "bg-transparent text-primary shadow-none hover:bg-primary/10", split === "right" ? "px-[10px]" : "px-[16px]", split === "left" ? "rounded-l-[12px] rounded-r-[4px] data-[pressed=true]:rounded-[20px]" : split === "right" ? "rounded-r-[12px] rounded-l-[4px] data-[pressed=true]:rounded-[20px] data-[state=open]:rounded-[20px]" : "rounded-[12px] data-[pressed=true]:rounded-[20px]", className),
		onPointerDown: (e) => {
			setPressed(true);
			onPointerDown?.(e);
		},
		onPointerUp: (e) => {
			setPressed(false);
			onPointerUp?.(e);
		},
		onPointerLeave: (e) => {
			setPressed(false);
			setSpot((s) => ({
				...s,
				on: false
			}));
			onPointerLeave?.(e);
		},
		onPointerMove: (e) => {
			const el = ref.current;
			if (!el) return;
			const r = el.getBoundingClientRect();
			setSpot({
				x: e.clientX - r.left,
				y: e.clientY - r.top,
				on: true
			});
			onPointerMove?.(e);
		},
		...props,
		children: [surface ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-0 z-0 overflow-hidden rounded-[inherit]",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-current opacity-0 transition-opacity duration-200 group-hover:opacity-[0.08]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute rounded-full bg-current",
				style: {
					width: 140,
					height: 140,
					left: spot.x - 70,
					top: spot.y - 70,
					opacity: spot.on ? .12 : 0,
					background: "radial-gradient(closest-side, currentcolor 65%, transparent 100%)",
					transition: "opacity 375ms linear"
				}
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative z-10 flex items-center justify-center gap-[inherit] pointer-events-none",
			children
		})]
	});
}
//#endregion
export { clamp as n, detectPlatform as r, TactileButton as t };
