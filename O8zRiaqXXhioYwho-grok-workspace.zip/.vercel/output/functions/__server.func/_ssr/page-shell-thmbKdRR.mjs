import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-shell-thmbKdRR.js
var import_jsx_runtime = require_jsx_runtime();
var brand = {
	name: "BrokeBase",
	tagline: "Open-source OSINT workstation",
	stars: "18k",
	year: 2026,
	legal: "BrokeBase Inc."
};
var platforms = [
	{
		id: "windows",
		label: "Windows",
		file: "BrokeBase-Setup-1.4.2.exe",
		href: "/download"
	},
	{
		id: "macos",
		label: "macOS",
		file: "BrokeBase-1.4.2.dmg",
		href: "/download"
	},
	{
		id: "linux",
		label: "Linux",
		file: "BrokeBase-1.4.2.AppImage",
		href: "/download"
	}
];
var testimonials = [
	{
		name: "Alex Rivera",
		handle: "@alexrivera",
		avatar: "/avatars/alex.jpg",
		quote: "BrokeBase completely leveled up our threat hunts. Clean graph, gorgeous motion, and ridiculously easy to wire in new sources."
	},
	{
		name: "Sarah Chen",
		handle: "@sarah_dev",
		avatar: "/avatars/sarah.jpg",
		quote: "The motion choreography is top tier. Swapped our old recon stack and had a live case file in under an hour."
	},
	{
		name: "Marcus Vance",
		handle: "@marcus_ui",
		avatar: "/avatars/marcus.jpg",
		quote: "Incredible attention to detail. The progressive blur, tactile buttons, and identity graph feel like a million bucks."
	},
	{
		name: "Elena Rostova",
		handle: "@elena_osint",
		avatar: "/avatars/elena.jpg",
		quote: "The dark-mode aesthetic and plugin system are absolutely flawless. Finally an OSINT desk that doesn’t look like 2014."
	},
	{
		name: "Jordan Lee",
		handle: "@jordan_tech",
		avatar: "/avatars/jordan.jpg",
		quote: "Best OSINT workstation I’ve used. The code is modular, type-safe, and the breach correlation actually holds up in court notes."
	},
	{
		name: "Samir Patel",
		handle: "@dev_sam",
		avatar: "/avatars/samir.jpg",
		quote: "Performance is buttery smooth even with full graph shaders and live source fan-out across a thousand nodes."
	}
];
var changelog = [
	{
		version: "1.4.2",
		date: "Sep 4, 2026",
		items: [
			"Faster Sherlock / WhatsMyName fan-out with cancellable jobs.",
			"Graph now clusters related breach collections.",
			"Linux AppImage signed with the BrokeBase key."
		]
	},
	{
		version: "1.4.0",
		date: "Aug 12, 2026",
		items: [
			"Censys + Shodan source plugins shipped.",
			"Case files: pin an identity, export PDF/JSON.",
			"Pixel-accurate dark chrome refresh."
		]
	},
	{
		version: "1.3.1",
		date: "Jun 28, 2026",
		items: ["Have I Been Pwned v3 adapter.", "Keyboard-first command palette."]
	}
];
function LayersMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.5",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className,
		"aria-hidden": "true",
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2L2 7l10 5 10-5-10-5z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2 17l10 5 10-5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2 12l10 5 10-5" })
		]
	});
}
function CubeMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22.106 5.68L12.5.135a.998.998 0 00-.998 0L1.893 5.68a.84.84 0 00-.419.726v11.186c0 .3.16.577.42.727l9.607 5.547a.999.999 0 00.998 0l9.608-5.547a.84.84 0 00.42-.727V6.407a.84.84 0 00-.42-.726zm-.603 1.176L12.228 22.92c-.063.108-.228.064-.228-.061V12.34a.59.59 0 00-.295-.51l-9.11-5.26c-.107-.062-.063-.228.062-.228h18.55c.264 0 .428.286.296.514z" })
	});
}
function WindowsMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801" })
	});
}
function AppleMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16.365 12.84c-.02-2.14 1.75-3.17 1.83-3.22-1-1.46-2.56-1.66-3.11-1.68-1.32-.13-2.58.77-3.25.77-.67 0-1.71-.75-2.81-.73-1.45.02-2.79.84-3.53 2.14-1.51 2.61-.39 6.47 1.08 8.59.72 1.04 1.58 2.2 2.71 2.16 1.09-.04 1.5-.7 2.81-.7 1.31 0 1.68.7 2.82.68 1.17-.02 1.91-1.06 2.62-2.1.83-1.2 1.17-2.37 1.19-2.43-.03-.01-2.27-.87-2.36-3.48zM14.5 6.96c.6-.73 1-1.74.89-2.76-.86.03-1.9.57-2.52 1.3-.55.64-1.04 1.67-.91 2.66.96.07 1.94-.49 2.54-1.2z" })
	});
}
function LinuxMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.5 3.2c.9 0 1.6.8 1.6 1.9 0 .5-.2 1-.5 1.3 1.4.5 2.4 1.9 2.4 3.7 0 1-.4 1.9-1 2.6.6.7 1 1.6 1 2.6 0 2.1-1.6 3.5-3.4 3.8.1 1.7-.9 3.3-2.6 3.3-1.7 0-2.7-1.6-2.6-3.3-1.8-.3-3.4-1.7-3.4-3.8 0-1 .4-1.9 1-2.6-.6-.7-1-1.6-1-2.6 0-1.8 1-3.2 2.4-3.7-.3-.3-.5-.8-.5-1.3 0-1.1.7-1.9 1.6-1.9.5 0 1 .2 1.3.6.3-.4.8-.6 1.3-.6z" })
	});
}
function GithubMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" })
	});
}
function XMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z" })
	});
}
function StarMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" })
	});
}
function ChevronDown({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m6 9 6 6 6-6" })
	});
}
function ClaudeMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "#D97757",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20.998 10.949H24v3.102h-3v3.028h-1.487V20H18v-2.921h-1.487V20H15v-2.921H9V20H7.488v-2.921H6V20H4.487v-2.921H3V14.05H0V10.95h3V5h17.998v5.949zM6 10.949h1.488V8.102H6v2.847zm10.51 0H18V8.102h-1.49v2.847z" })
	});
}
function OpenAiMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8.086.457a6.105 6.105 0 013.046-.415c1.333.153 2.521.72 3.564 1.7a.117.117 0 00.107.029c1.408-.346 2.762-.224 4.061.366l.063.03.154.076c1.357.703 2.33 1.77 2.918 3.198.278.679.418 1.388.421 2.126a5.655 5.655 0 01-.18 1.631.167.167 0 00.04.155 5.982 5.982 0 011.578 2.891c.385 1.901-.01 3.615-1.183 5.14l-.182.22a6.063 6.063 0 01-2.934 1.851.162.162 0 00-.108.102c-.255.736-.511 1.364-.987 1.992-1.199 1.582-2.962 2.462-4.948 2.451-1.583-.008-2.986-.587-4.21-1.736a.145.145 0 00-.14-.032c-.518.167-1.04.191-1.604.185a5.924 5.924 0 01-2.595-.622 6.058 6.058 0 01-2.146-1.781c-.203-.269-.404-.522-.551-.821a7.74 7.74 0 01-.495-1.283 6.11 6.11 0 01-.017-3.064.166.166 0 00.008-.074.115.115 0 00-.037-.064 5.958 5.958 0 01-1.38-2.202 5.196 5.196 0 01-.333-1.589 6.915 6.915 0 01.188-2.132c.45-1.484 1.309-2.648 2.577-3.493.282-.188.55-.334.802-.438.286-.12.573-.22.861-.304a.129.129 0 00.087-.087A6.016 6.016 0 015.635 2.31C6.315 1.464 7.132.846 8.086.457zm-.804 7.85a.848.848 0 00-1.473.842l1.694 2.965-1.688 2.848a.849.849 0 001.46.864l1.94-3.272a.849.849 0 00.007-.854l-1.94-3.393zm5.446 6.24a.849.849 0 000 1.695h4.848a.849.849 0 000-1.696h-4.848z" })
	});
}
function CursorMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9.27 15.29l7.978-5.897c.391-.29.95-.177 1.137.272.98 2.369.542 5.215-1.41 7.169-1.951 1.954-4.667 2.382-7.149 1.406l-2.711 1.257c3.889 2.661 8.611 2.003 11.562-.953 2.341-2.344 3.066-5.539 2.388-8.42l.006.007c-.983-4.232.242-5.924 2.75-9.383.06-.082.12-.164.179-.248l-3.301 3.305v-.01L9.267 15.292M7.623 16.723c-2.792-2.67-2.31-6.801.071-9.184 1.761-1.763 4.647-2.483 7.166-1.425l2.705-1.25a7.808 7.808 0 00-1.829-1A8.975 8.975 0 005.984 5.83c-2.533 2.536-3.33 6.436-1.962 9.764 1.022 2.487-.653 4.246-2.34 6.022-.599.63-1.199 1.259-1.682 1.925l7.62-6.815" })
	});
}
function TerminalMark({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className,
		"aria-hidden": "true",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 6H8v12h8V6zm4 16H4V2h16v20z" })
	});
}
function SiteHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed left-0 z-40 w-full select-none",
		style: {
			top: 0,
			height: 120,
			background: "linear-gradient(to top, transparent, rgb(0, 0, 0))",
			maskImage: "linear-gradient(rgb(0, 0, 0) 50%, transparent)",
			backdropFilter: "blur(8px)"
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed top-2 left-1/2 z-50 flex -translate-x-1/2 select-none items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/",
			className: "flex items-center gap-[0.3em] text-lg font-semibold text-zinc-200",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayersMark, { className: "inline-block h-[0.85em] w-auto text-white" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: brand.name })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "https://github.com/",
			target: "_blank",
			rel: "noopener noreferrer",
			className: "relative z-0 flex isolate cursor-pointer select-none items-center overflow-hidden whitespace-nowrap rounded-full bg-zinc-900/80 px-2.5 py-1 text-[10px] font-medium text-zinc-300 shadow-[0_0_0_1px_rgba(255,255,255,0.08),0_4px_12px_-4px_rgba(0,0,0,0.6)] backdrop-blur-md transition-[box-shadow,background-color,scale] duration-200 ease-out hover:bg-zinc-800/90 hover:shadow-[0_0_0_1px_rgba(255,255,255,0.15),0_8px_20px_-8px_rgba(0,0,0,0.7)] active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white/40",
			"aria-label": `${brand.stars} stars on GitHub`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative z-10 flex items-center gap-1.5 whitespace-nowrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarMark, { className: "size-3 flex-none text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "whitespace-nowrap leading-none",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: brand.stars
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: " stars" })]
				})]
			})
		})]
	})] });
}
function PageShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full bg-black text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), children]
	});
}
//#endregion
export { testimonials as _, CursorMark as a, LinuxMark as c, TerminalMark as d, WindowsMark as f, platforms as g, changelog as h, CubeMark as i, OpenAiMark as l, brand as m, ChevronDown as n, GithubMark as o, XMark as p, ClaudeMark as r, LayersMark as s, AppleMark as t, PageShell as u };
