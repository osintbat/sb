import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { u as PageShell } from "./page-shell-thmbKdRR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/docs-C2UlZqCc.js
var import_jsx_runtime = require_jsx_runtime();
var sections = [
	{
		id: "hunt",
		title: "Hunt",
		body: "Drop an email, username, domain, phone, or IP into the command bar. BrokeBase fans the query across enabled sources in parallel, then folds hits into a single identity record. Jobs are cancellable. Nothing leaves your machine unless a source plugin is explicitly on."
	},
	{
		id: "graph",
		title: "Identity graph",
		body: "Every confirmed link — reused handle, matching breach combo, shared infrastructure — becomes an edge. Cluster by collection, pivot with keyboard, pin a node to the case file. Export JSON or a one-page PDF for notes that have to leave the desk."
	},
	{
		id: "sources",
		title: "Sources",
		body: "First-party adapters ship for Have I Been Pwned, Shodan, Censys, VirusTotal, Sherlock, and WhatsMyName. Bring your own keys. Plugins are TypeScript modules with a tiny contract: query, normalize, emit. Zero vendor lock-in — disable any source without breaking the graph."
	},
	{
		id: "opsec",
		title: "OPSEC",
		body: "Default posture is local-first. Proxy per source, no cloud account required, case files encrypted at rest with the OS keychain. Do not use BrokeBase against people or systems you are not authorized to investigate."
	}
];
function DocsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-3xl px-6 pb-24 pt-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500",
				children: "Documentation"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-white sm:text-5xl",
				children: "The desk, in four moves"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-pretty text-sm leading-relaxed text-zinc-400",
				children: "BrokeBase is an open-source OSINT workstation. Same cinematic chrome as the landing — this page is the operator brief."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 space-y-12",
				children: sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: s.id,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold tracking-tight text-white",
						children: s.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-pretty text-sm leading-relaxed text-zinc-400",
						children: s.body
					})]
				}, s.id))
			})
		]
	}) });
}
//#endregion
export { DocsPage as component };
