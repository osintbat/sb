import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { h as changelog, u as PageShell } from "./page-shell-thmbKdRR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/changelog-CM0-DTIj.js
var import_jsx_runtime = require_jsx_runtime();
function ChangelogPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-3xl px-6 pb-24 pt-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500",
				children: "Release notes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-white sm:text-5xl",
				children: "Changelog"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-14 space-y-12",
				children: changelog.map((rel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-mono text-sm font-semibold text-white",
						children: ["v", rel.version]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-zinc-500",
						children: rel.date
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2 text-sm leading-relaxed text-zinc-400",
					children: rel.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1 shrink-0 rounded-full bg-zinc-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-pretty",
							children: item
						})]
					}, item))
				})] }, rel.version))
			})
		]
	}) });
}
//#endregion
export { ChangelogPage as component };
