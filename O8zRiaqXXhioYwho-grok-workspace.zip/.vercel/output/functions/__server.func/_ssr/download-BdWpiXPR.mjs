import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as LinuxMark, f as WindowsMark, g as platforms, t as AppleMark, u as PageShell } from "./page-shell-thmbKdRR.mjs";
import { r as detectPlatform, t as TactileButton } from "./tactile-button-CMgqa7fZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/download-BdWpiXPR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var marks = {
	windows: WindowsMark,
	macos: AppleMark,
	linux: LinuxMark
};
function DownloadPage() {
	const [platform, setPlatform] = (0, import_react.useState)("windows");
	(0, import_react.useEffect)(() => {
		setPlatform(detectPlatform());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-3xl flex-col justify-center px-6 pb-24 pt-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] font-medium uppercase tracking-[0.25em] text-zinc-500",
				children: "Desktop builds"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-white sm:text-5xl",
				children: "Download BrokeBase"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 max-w-xl text-pretty text-sm leading-relaxed text-zinc-400",
				children: [
					"Native OSINT workstation for Windows, macOS, and Linux. Same engine, same plugins, signed builds. Pick your platform — we detected",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-zinc-200",
						children: platform
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-3",
				children: platforms.map((p) => {
					const Icon = marks[p.id];
					const active = p.id === platform;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: ["flex items-center gap-4 rounded-2xl border p-4 backdrop-blur-md transition-colors", active ? "border-white/20 bg-zinc-900/90" : "border-white/10 bg-zinc-950/60 hover:border-white/15"].join(" "),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-12 items-center justify-center rounded-full border border-white/15 bg-zinc-900",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-semibold text-zinc-100",
									children: [p.label, active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 text-[10px] font-medium uppercase tracking-wider text-zinc-500",
										children: "detected"
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-0.5 font-mono text-[11px] text-zinc-500",
									children: p.file
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TactileButton, {
								type: "button",
								onClick: () => {
									const blob = new Blob([`BrokeBase ${p.label} build placeholder\n${p.file}\nThis preview ships a demo landing — hook your release artifacts here.\n`], { type: "text/plain" });
									const url = URL.createObjectURL(blob);
									const a = document.createElement("a");
									a.href = url;
									a.download = p.file.replace(/\.\w+$/, ".txt");
									a.click();
									URL.revokeObjectURL(url);
								},
								children: "Download"
							})
						]
					}, p.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-xs text-zinc-500",
				children: [
					"Looking for source?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://github.com/",
						className: "text-zinc-300 underline-offset-4 hover:underline",
						target: "_blank",
						rel: "noopener noreferrer",
						children: "Clone the repo"
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/docs",
						className: "text-zinc-300 underline-offset-4 hover:underline",
						children: "Read the docs"
					})
				]
			})
		]
	}) });
}
//#endregion
export { DownloadPage as component };
