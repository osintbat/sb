//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-dthp18WY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/changelog",
			"/docs",
			"/download"
		],
		preloads: ["/assets/index-CAatl5k-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CAatl5k-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CRlfRGVQ.js",
			"/assets/page-shell-qL75SJvm.js",
			"/assets/tactile-button-CumBN6n2.js"
		]
	},
	"/changelog": {
		filePath: "/workspace/src/routes/changelog.tsx",
		children: void 0,
		preloads: ["/assets/changelog-CR-GzW6I.js", "/assets/page-shell-qL75SJvm.js"]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: ["/assets/docs-B_6WyxJB.js", "/assets/page-shell-qL75SJvm.js"]
	},
	"/download": {
		filePath: "/workspace/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-BmBVzD1j.js",
			"/assets/page-shell-qL75SJvm.js",
			"/assets/tactile-button-CumBN6n2.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
